import datetime
import logging
import os
import pickle
import itertools

from grounding.semnet import Sign

DEFAULT_FILE_PREFIX = 'wmodel_'
DEFAULT_FILE_SUFFIX = '.swm'

SIT_COUNTER = 0
SIT_PREFIX = 'situation_'
PLAN_PREFIX = 'action_'
MAP_PREFIX = 'map_'


class Task:
    def __init__(self, name, signs, constraints, start_situation, goal_situation, logic, goal_map, map_precisions, additions):
        self.name = name
        self.signs = signs
        self.start_situation = start_situation
        self.goal_situation = goal_situation
        self.goal_map = goal_map
        self.constraints = constraints
        self.additions = additions
        self.map_precisions = map_precisions
        self.logic = logic

    def __str__(self):
        s = 'Task {0}\n  Signs:  {1}\n  Start:  {2}\n  Goal: {3}\n'
        return s.format(self.name, '\n'.join(map(repr, self.signs)),
                        self.start_situation, self.goal_situation)

    def __repr__(self):
        return '<Task {0}, signs: {1}>'.format(self.name, len(self.signs))

    def save_signs(self, plan):
        def __is_role(pm):
            chains = pm.spread_down_activity('meaning', 6)
            for chain in chains:
                if len(chain[-1].sign.significances[1].cause) != 0:
                    break
            else:
                return False
            return True

        I_obj = None
        logging.info('Plan preparation to save...')
        if plan:
            logging.info('\tCleaning SWM...')
            pms_sit = [pm[0] for pm in plan[:-1]]
            pms_act = [pm[2] for pm in plan[:-1]]
            deleted = []
            for name, s in self.signs.copy().items():
                signif=list(s.significances.items())
                if name.startswith(SIT_PREFIX):
                    for index, pm in s.meanings.copy().items():
                        if pm not in pms_sit:
                            s.remove_meaning(pm) # delete all situations
                            deleted.append(pm)
                    self.signs.pop(name)
                elif len(signif):
                    if len(signif[0][1].cause) and len(signif[0][1].effect): #delete action's meanings that are not in plan
                        for index, pm in s.meanings.copy().items():
                            # if pm not in pms_act:
                            #     s.remove_meaning(pm)
                            if __is_role(pm):  # delete only fully signed actions
                                break
                            else:
                                if pm not in pms_act:
                                    s.remove_meaning(pm)




            They_signs = [con.in_sign for con in self.signs["They"].out_significances]
            I_obj = [con.in_sign for con in self.signs["I"].out_significances if con.out_sign.name == "I"]

            for agent in itertools.chain(They_signs, I_obj):
                for connector in list(agent.out_meanings.copy()):
                    pm = connector.in_sign.meanings[connector.in_index]
                    if pm not in pms_act:
                        if __is_role(pm):  # delete only fully signed actions
                                break
                        else:
                            agent.out_meanings.remove(connector)

            logging.info('\tSaving precedent...')
            self.start_situation.name += self.name
            self.goal_situation.name += self.name
            dm = self.start_situation.meanings[1].copy('meaning', 'image')
            self.start_situation.add_image(dm)
            dm = self.goal_situation.meanings[1].copy('meaning', 'image')
            self.goal_situation.add_image(dm)
            # in start and goal sit out_meanings insert connector to plan sign
            plan_sign = Sign(PLAN_PREFIX + self.name)
            plan_mean = plan_sign.add_meaning()
            connector = plan_mean.add_feature(self.start_situation.meanings[1])
            self.start_situation.add_out_meaning(connector)
            conn = plan_mean.add_feature(self.goal_situation.meanings[1], effect=True)
            self.goal_situation.add_out_meaning(conn)


            plan_image = plan_sign.add_image()

            for _, name, cm, agent, _ in plan[:-1]:
                im = cm.sign.add_image()
                #im = cm.copy('meaning', 'image')
                connector = plan_image.add_feature(im)
                cm.sign.add_out_image(connector) # add connector to plan_sign threw images to out_image


            self.signs[plan_sign.name] = plan_sign
            self.signs[self.start_situation.name] = self.start_situation
            self.signs[self.goal_situation.name] = self.goal_situation
        else:
            for name, sign in self.signs.copy().items():
                if name.startswith(SIT_PREFIX):
                    self.signs.pop(name)
                else:
                    sign.meanings = {}
                    sign.out_meanings = []
        if I_obj:
            I_obj = "_"+I_obj[0].name
        else:
            I_obj = 'I'
        file_name = DEFAULT_FILE_PREFIX + datetime.datetime.now().strftime('%m_%d_%H_%M') + I_obj + DEFAULT_FILE_SUFFIX
        logging.info('Start saving to {0}'.format(file_name))
        logging.info('\tDumping SWM...')
        pickle.dump(self.signs, open(file_name, 'wb'))
        logging.info('\tDumping SWM finished')
        return file_name

    @staticmethod
    def load_signs(agent, file_name=None):
        if not file_name:
            file_name = []
            for f in os.listdir('.'):
                if f.endswith(DEFAULT_FILE_SUFFIX) and f.split(".")[0].endswith(agent):
                    file_name.append(f)
        else:
            file_name = [file_name]
        if file_name:
            newest = 0
            file_load = ''
            for file in file_name:
                file_signature = int(''.join([i if i.isdigit() else '' for i in file]))
                if file_signature > newest:
                    newest = file_signature
                    file_load = file
            signs = pickle.load(open(file_load, 'rb'))
        else:
            logging.info('File not found')
            return None
        return signs
